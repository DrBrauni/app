import React, { Component, lazy, Suspense } from 'react'
import './index.scss'
import 'antd/dist/antd.min.css'
import { BrowserRouter, Route, Switch } from 'react-router-dom'
import { DesktopRouter } from './components/desktop/desktop-router'
import menuStore from './components/mobile-store/menu-store'
import { Provider } from 'mobx-react'
import MobileRouter from './components/mobile/mobile-router'

const MainDesktop = lazy(() => import(DesktopRouter))
const MainMobile = lazy(
  () => import(<Provider menuStore={menuStore}>MobileRouter</Provider>))

function DesktopVersion (props) {
  return (
    <Switch>
      <Route path='/'>
        {props.width >= 1100 ? <DesktopRouter />
          : <Suspense fallback={<div>Loading...</div>}><MainMobile /></Suspense>}
      </Route>
    </Switch>
  )
}

function MobileVersion (props) {
  return (
    <Switch>
      <Route path='/'>
        {props.width < 1100 ? <Provider
          menuStore={menuStore}
        ><MobileRouter />
                              </Provider>
          : <Suspense
            fallback={<div>Loading...</div>}
          ><MainDesktop />
          </Suspense>}
      </Route>
    </Switch>
  )
}

class App extends Component {
  constructor (props) {
    super(props)
    this.state = { width: 0, height: 0 }
    this.updateWindowDimensions = this.updateWindowDimensions.bind(this)
  }

  componentDidMount () {
    this.updateWindowDimensions()
    window.addEventListener('resize', this.updateWindowDimensions)
  }

  componentWillUnmount () {
    window.removeEventListener('resize', this.updateWindowDimensions)
  }

  updateWindowDimensions () {
    this.setState({ width: window.innerWidth, height: window.innerHeight })
  }

  render () {
    const { width } = this.state
    console.log(width < 1100)
    return (
      <BrowserRouter>
        {width < 1110 ? <MobileVersion width={width} /> : <DesktopVersion
          width={width}
                                                          />}
      </BrowserRouter>
    )
  }
}

export default App
