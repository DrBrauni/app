import React, { Suspense, useState } from 'react'
import { Route, Switch } from 'react-router-dom'
import FlatDesktop from './kvart/main'
import { OfficeDesktop } from './ofis/main'
import { HomeDesktop } from './dom/main'
import { GardenDesktop } from './uchast/main'
import { ContactsDesktop } from './contacts/main'
import { MainPageDesktop } from './main-page/main'
import flatStore from '../store/flat_store'
import { Provider } from 'mobx-react'
import Footer from './all-components/footer/footer'
import Header from './all-components/header/head'

export function DesktopRouter (props) {
  const [num, setNum] = useState(1)
  return (
    <>
      <Header num={num} />
      <Switch>
        <Route path='/flat'>
          <Provider flatStore={flatStore}><FlatDesktop /></Provider>
        </Route>
        <Route path='/office'>
          <OfficeDesktop />
        </Route>
        <Route path='/home'>
          <HomeDesktop />
        </Route>
        <Route path='/garden'>
          <GardenDesktop />
        </Route>
        <Route path='/contacts'>
          <ContactsDesktop />
        </Route>
        <Route path='/'>
          <MainPageDesktop />
        </Route>
      </Switch>
      <div style={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
        <div style={{ width: 1110, display: 'flex', justifyContent: 'center' }}>
          <Footer />
        </div>
      </div>
    </>
  )
}
