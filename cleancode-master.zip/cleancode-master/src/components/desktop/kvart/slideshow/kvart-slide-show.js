import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './kvart-slideshow.scss'
import { SectionName } from '../../../mobile/utils-component/section-name/section-name'
import { observer, inject } from 'mobx-react'
import packetStore from '../../../store/packet_store'

const kvartSlideshow = cn('kvart-slideshow-desktop')

const Slide = inject('flatStore')(
  observer(class Slide extends Component {
    render () {
      return (
        <>
          <div
            onClick={() => this.props.flatStore.setPacket(this.props.name)}
            className={kvartSlideshow('slide', { active: this.props.active })}
          >
            <div className={kvartSlideshow('text')}>{this.props.text}</div>
          </div>
        </>
      )
    }
  }))

const KvartSlideShow = inject('flatStore')(
  observer(class ThirdSlideShow extends Component {
    render () {
      console.log(this.props)
      const packet = this.props.flatStore.packet
      return (
        <>
          <section className={kvartSlideshow()}>
            <div className={kvartSlideshow('container')}>
              <Slide
                text='Готовые пакеты' active={packet === 1}
                name={1}
              />
              <Slide
                text='Доп. Услуги' active={packet === 2}
                name={2}
              />
              <Slide text='После ремонта' active={packet === 3} name={3} />
            </div>
          </section>
        </>)
    }
  }))

export default KvartSlideShow
