import React from 'react'
import { SectionName } from '../../mobile/utils-component/section-name/section-name'
import KvartSlideShow from './slideshow/kvart-slide-show'
import After from './afterrepair/first'
import Packets from './packets/first'
import Additional from './additional/first'
import { inject, observer } from 'mobx-react'

const FlatDesktop = inject('flatStore')(
  observer(function FlatDesktop (props) {
    const { packet } = props.flatStore
    console.log(packet)
    return (<>
      <SectionName
        text='Полный прайс на услуги клининга в квартирах'
        full_width font={30} top={0}
      />
      <KvartSlideShow />
      {packet === 1 ? <Packets /> : ''}
      {packet === 2 ? <Additional /> : ''}
      {packet === 3 ? <After /> : ''}
    </>)
  }))

export default FlatDesktop
