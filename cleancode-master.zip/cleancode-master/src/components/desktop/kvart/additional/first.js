import React from 'react'
import { cn } from '@bem-react/classname'
import ExpandedText from '../expanded-text/expanded-text'
import './first.scss'
import { inject, observer } from 'mobx-react'

const flat = cn('flat-additional-desktop')

function Content () {
  return (
    <div className={flat('main-main-container')}>
      <div className={flat('main-container')}>
        <div className={flat('first-container')}>
          <div
            className={flat('local-header')}
            style={{ marginLeft: 0 }}
          >Мойка стандартных окон:
          </div>
          <div className={flat('a')}>
            <div className={flat('b')}>
              <div className={flat('ba')}>1 окно</div>
              <div className={flat('bac')}>150р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>2 окна</div>
              <div className={flat('bac')}>250р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>3 окна</div>
              <div className={flat('bac')}>от 500р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>балкон</div>
              <div className={flat('bac')}>800р</div>
            </div>
          </div>
          <div
            className={flat('local-header')}
            style={{ marginLeft: 0 }}
          >Мойка бытовой техники внутри:
          </div>
          <div className={flat('a')}>
            <div className={flat('b')}>
              <div className={flat('ba')}>Холодильник</div>
              <div className={flat('bac')}>350р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Микроволновка</div>
              <div className={flat('bac')}>180р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Духовой шкаф</div>
              <div className={flat('bac')}>от 350р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Посудомойка</div>
              <div className={flat('bac')}>350р</div>
            </div>
          </div>
          <div
            className={flat('local-header')}
            style={{ marginLeft: 0 }}
          >Остальное:
          </div>
          <div className={flat('a')}>
            <div className={flat('b')}>
              <div className={flat('ba')}>Посуда</div>
              <div className={flat('bac')}>150р/ч</div>
            </div>
          </div>
        </div>
        <div className={flat('second-container')}>
          <div
            className={flat('local-header')}
            style={{ marginLeft: 0 }}
          >Химчистка диванов:
          </div>
          <div className={flat('a')}>
            <div className={flat('b')}>
              <div className={flat('ba')}>Угловой</div>
              <div className={flat('bac')}>150р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Прямой</div>
              <div className={flat('bac')}>250р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Мини</div>
              <div className={flat('bac')}>от 500р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Кресло</div>
              <div className={flat('bac')}>800р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Стул</div>
              <div className={flat('bac')}>400р</div>
            </div>
            <div
              className={flat('local-header')}
              style={{ marginLeft: 0 }}
            >Химчистка матрасов:
            </div>
            <div className={flat('a')}>
              <div className={flat('b')}>
                <div className={flat('ba')}>Односпальный</div>
                <div className={flat('bac')}>350р</div>
              </div>
              <div className={flat('b')}>
                <div className={flat('ba')}>Полутороспальный</div>
                <div className={flat('bac')}>180р</div>
              </div>
              <div className={flat('b')}>
                <div className={flat('ba')}>Двухспальный</div>
                <div className={flat('bac')}>от 350р</div>
              </div>
              <div className={flat('b')}>
                <div className={flat('ba')}>Детский</div>
                <div className={flat('bac')}>350р</div>
              </div>
            </div>
          </div>
        </div>
        <div className={flat('third-container')}>
          <div
            className={flat('local-header')}
            style={{ marginLeft: 0 }}
          >Другие доп. услуги:
          </div>
          <div className={flat('a')}>
            <div className={flat('b')}>
              <div className={flat('ba')}>Уборка балкона</div>
              <div className={flat('bac')}>150р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Дети дома/ЭКО</div>
              <div className={flat('bac')}>250р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Глажка белья</div>
              <div className={flat('bac')}>от 500р</div>
            </div>
            <div className={flat('b')}>
              <div className={flat('ba')}>Уборка снега</div>
              <div className={flat('bac')}>800р</div>
            </div>
          </div>
          <div className={flat('bd')}>
            {'Вы можете легко расчитать\nстоимость для своей квартиры\nв нашем калькуляторе'}
          </div>
          <button className={flat('button')}>Использовать калькулятор</button>
        </div>
      </div>
    </div>
  )
}

export default Content
