import React from 'react'
import { cn } from '@bem-react/classname'
import ExpandedText from '../expanded-text/expanded-text'
import './first.scss'
import { inject, observer } from 'mobx-react'

const flat = cn('flat-packets-desktop')

const Content = inject('flatStore')(
  observer(function content (props) {
    const { subpacket } = props.flatStore
    console.log(props)
    return (
      <div className={flat('main-main-container')}>
        <div className={flat('container-header')}>
          <div
            className={subpacket === 1 ? 'active' : ''}
            onClick={() => props.flatStore.setSubPacket(1)}
          >Могу позволить
          </div>
          <div
            className={subpacket === 2 ? 'active' : ''}
            onClick={() => props.flatStore.setSubPacket(2)}
          >Пора отдохнуть
          </div>
          <div
            className={subpacket === 3 ? 'active' : ''}
            onClick={() => props.flatStore.setSubPacket(3)}
          >Всё и сразу
          </div>
        </div>
        <div className={flat('main-container')}>
          <div className={flat('first-container')}>
            <div className={flat('local-header')}>Кухня
            </div>
            <ExpandedText text={props.flatStore.Cook} num={0} />
            <div className={flat('local-header', { type: 'second' })}>Комната
            </div>
            <ExpandedText text={props.flatStore.Room} num={1} />
            <div className={flat('local-header', { type: 'second' })}>Ванная
            </div>
            <ExpandedText text={props.flatStore.Wish} num={2} />
          </div>
          <div className={flat('second-container')}>
            <div
              className={flat('local-header')}
              style={{ marginLeft: 0 }}
            >Стоимость:
            </div>
            <div className={flat('a')}>
              <div className={flat('b')}>
                <div className={flat('ba')}>1 комната</div>
                <div className={flat('bac')}>{props.flatStore.Cost[0]}р</div>
              </div>
              <div className={flat('b')}>
                <div className={flat('ba')}>2 комната</div>
                <div className={flat('bac')}>{props.flatStore.Cost[1]}р</div>
              </div>
              <div className={flat('b')}>
                <div className={flat('ba')}>3 комната</div>
                <div className={flat('bac')}>{props.flatStore.Cost[2]}р</div>
              </div>
              <div className={flat('b')}>
                <div className={flat('ba')}>от 70 до 90 м<sup>2</sup></div>
                <div className={flat('bac')}>{props.flatStore.Cost[3]}р</div>
              </div>
            </div>
            <div className={flat('bd')}>
              {'Готовы навести чистоту в доме?\n Оставьте заявку и мы перезвоним!'}
            </div>
            <form className={flat('form')}>
              <div className={flat('form-input')}>
                <label>
                  <input
                    required
                  />
                  <span className='placeholder'>Введите ваше имя</span>
                </label>
              </div>
              <div className={flat('form-input')}>
                <label>
                  <input required /><span className='placeholder'>Введите ваш телефон</span>
                </label>
              </div>
            </form>
            <button className={flat('button')}>Заказать</button>
            <div className={flat('small-advice')}>Нажимая кнопку
              «Заказать», Вы принимаете <a>соглашение на обработку персональных
                данных
                                        </a>
            </div>
          </div>

        </div>
      </div>
    )
  }))

export default Content
