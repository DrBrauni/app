import React from 'react'

export function ContactsDesktop () {
  return (<>
    <div className='main-container' />
          </>)
}
