import React from 'react'
import { SectionName } from '../../mobile/utils-component/section-name/section-name'
import Content from './first/first'

export function GardenDesktop () {
  return (<>
    <SectionName
      text='Благоустройство и комплексное обслуживание участка'
      full_width font={30} top={0}
    />
    <Content />
  </>)
}
