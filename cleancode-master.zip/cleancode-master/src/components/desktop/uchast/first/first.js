import React from 'react'
import { cn } from '@bem-react/classname'
import ExpandedText from '../expanded-text/expanded-text'
import './first.scss'

const uchastok = cn('uchastok-desktop')

const content = () => {
  const data = ['<ul><li>Прочистка пешеходных дорожек</li>\n' +
  '<li>Освобождение проезда для автомобилей</li>\n' +
  '<li>Разбивка и удаление льда</li>\n' +
  '<li>Вывоз снега при необходимости</li>\n' +
  '<li>Обработка дорожек против скольжения</li></ul>',
  '<ul><li>Услуги садовника</li>\n' +
    '<li>Покос травы и газона</li>\n' +
    '<li>Стрижка кустарных растений</li>\n' +
    '<li>Помощник по огороду</li>\n' +
    '<li>Выгул домашних животных</li>\n' +
    '<li>Очистка инвентаря сада и огорода</li>\n' +
    '<li>Поддержания чистоты территории</li></ul>'
  ]

  return (
    <div className={uchastok('main-main-container')}>
      <div className={uchastok('main-container')}>
        <div className={uchastok('first-container')}>
          <div className={uchastok('local-header')}>Что входит в комплекс убоки
            снега
          </div>
          <ExpandedText text={data[0]} expanded={false} />
          <div className={uchastok('local-header', { type: 'second' })}>Что входит в ежемесячное
            комплексное обслуживание участка
          </div>
          <ExpandedText text={data[1]} expanded />
        </div>
        <div className={uchastok('second-container')}>
          <div className={uchastok('local-header')} style={{ marginLeft: 0 }}>Стоимость:</div>
          <div className={uchastok('a')}>
            <div className={uchastok('b')}>
              <div className={uchastok('ba')}>Уборка снега</div>
              <div className={uchastok('bac')}>400р/ч</div>
            </div>
            <div className={uchastok('b')}>
              <div className={uchastok('ba')}>Обслуживание участка</div>
              <div className={uchastok('bac')}>от 15 000р</div>
            </div>
          </div>
          <div className={uchastok('bd')}>
            {'Нужны дополнительные услуги?\n Обговорим индивидуально'}
          </div>
          <form className={uchastok('form')}>
            <div className={uchastok('form-input')}>
              <label>
                <input
                  required
                />
                <span className='placeholder'>Введите ваше имя</span>
              </label>
            </div>
            <div className={uchastok('form-input')}>
              <label>
                <input required /><span className='placeholder'>Введите ваш телефон</span>
              </label>
            </div>
          </form>
          <button className={uchastok('button')}>Заказать</button>
          <div className={uchastok('small-advice')}>Нажимая кнопку
            «Заказать», Вы принимаете <a>соглашение на обработку персональных данных </a>
          </div>
        </div>

      </div>
    </div>
  )
}

export default content
