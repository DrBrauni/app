import React from 'react'
import { cn } from '@bem-react/classname'
import ExpandedText from '../expanded-text/expanded-text'
import './first.scss'

const office = cn('office-desktop')

const content = () => {
  const data = [
    '<ul><li>Удаление пыли и грязи с полов и плинтусов и последующая влажная уборка</li>\n' +
    '<li>Мойка окон и влажная уборка подоконников</li>\n' +
    '<li>Влажная внешняя уборка всех видов мебели, предметов интерьера и дверей</li>\n' +
    '<li>Очистка зеркальных и стеклянных поверхностей</li>\n' +
    '<li>Влажная и сухая протирка осветительных приборов, розеток и выключателей</li>\n' +
    '<li>Уборка сан.узлов</li>\n' +
    '<li>Чистка кухни и удаление специфических загрязнений</li>\n' +
    '<li>Вынос мусора</li>\n' +
    '<li>Мытье отопительных труб и батарей</li>\n' +
    '<li>Влажная и сухая протирка орг. техники, карнизов, кондиционеров, гардин</li></ul>',
    '<ul><li>Влажная уборка пола и плинтусов</li>\n' +
    '<li>Влажная уборка подоконников</li>\n' +
    '<li>Уборка сан узлов</li>\n' +
    '<li>Очистка зеркал и стеклянных поверхностей</li>\n' +
    '<li>Вынос мусора</li></ul>'
  ]

  return (
    <div className={office('main-main-container')}>
      <div className={office('main-container')}>
        <div className={office('first-container')}>
          <div className={office('local-header')}>Перечень работ входящих в
            генеральную уборку и уборку после ремонта
          </div>
          <ExpandedText text={data[0]} num={0} expanded />
          <div className={office('local-header', { type: 'second' })}>Перечень
            работ входящих в ежедневную уборку и уборку 2 раза в неделю
          </div>
          <ExpandedText text={data[1]} num={1} />
        </div>
        <div className={office('second-container')}>
          <div
            className={office('local-header')}
            style={{ marginLeft: 0 }}
          >Стоимость:
          </div>
          <div className={office('a')}>
            <div className={office('b')}>
              <div className={office('bs')}>Ежедневная уборка офисов</div>
            </div>
            <div className={office('b')}>
              <div className={office('ba')}>меньше 500м<sup>2</sup></div>
              <div className={office('bac')}>от 40р/м<sup>2</sup></div>
            </div>
            <div className={office('b')}>
              <div className={office('ba')}>больше 500м<sup>2</sup></div>
              <div className={office('bac')}>от 30р/м<sup>2</sup></div>
            </div>
            <div className={office('b')}>
              <div className={office('bs')}>Генеральная уборка офисов</div>
            </div>
            <div className={office('b')}>
              <div className={office('ba')}>меньше 500м<sup>2</sup></div>
              <div className={office('bac')}>от 70р/м<sup>2</sup></div>
            </div>
            <div className={office('b')}>
              <div className={office('ba')}>больше 500м<sup>2</sup></div>
              <div className={office('bac')}>от 60р/м<sup>2</sup></div>
            </div>
            <div className={office('b')}>
              <div className={office('bs')}>Уборка помещений после ремонта</div>
            </div>
            <div className={office('b')}>
              <div className={office('ba')}>меньше 500м<sup>2</sup></div>
              <div className={office('bac')}>от 90р/м<sup>2</sup></div>
            </div>
            <div className={office('b')}>
              <div className={office('ba')}>больше 500м<sup>2</sup></div>
              <div className={office('bac')}>от 80р/м<sup>2</sup></div>
            </div>
            <div className={office('b')}>
              <div className={office('bs')}>Уборка офисов 2 раза в неделю</div>
            </div>
            <div className={office('b')}>
              <div className={office('ba')}>меньше 500м<sup>2</sup></div>
              <div className={office('bac')}>от 30р/м<sup>2</sup></div>
            </div>
            <div className={office('b')}>
              <div className={office('ba')}>больше 500м<sup>2</sup></div>
              <div className={office('bac')}>от 25р/м<sup>2</sup></div>
            </div>
          </div>
          <div className={office('bd')}>
            {'Составим график\nне отвлекающий от рабочего процесса!\n\nПри заключении договора\nна длительное обслуживание\nпервая уборка бесплатно!\n\n Цены обговариваются индивидуально!'}
          </div>
          <form className={office('form')}>
            <div className={office('form-input')}>
              <label>
                <input
                  required
                />
                <span className='placeholder'>Введите ваше имя</span>
              </label>
            </div>
            <div className={office('form-input')}>
              <label>
                <input required /><span className='placeholder'>Введите ваш телефон</span>
              </label>
            </div>
          </form>
          <button className={office('button')}>Заказать</button>
          <div className={office('small-advice')}>Нажимая кнопку
            «Заказать», Вы принимаете <a>соглашение на обработку персональных
              данных
                                      </a>
          </div>
        </div>

      </div>
    </div>
  )
}

export default content
