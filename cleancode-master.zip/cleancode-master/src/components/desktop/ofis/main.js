import React from 'react'
import { SectionName } from '../../mobile/utils-component/section-name/section-name'
import Content from './first/first'

export function OfficeDesktop () {
  return (<>
    <SectionName
      text='Уборка офисных и коммерческих помещений'
      full_width font={30} top={0}
    />
    <Content />
  </>)
}
