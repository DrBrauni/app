import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './expanded-text.scss'
import { inject, observer } from 'mobx-react'

const expandedText = cn('expanded-text-desktop')

const ExpandedText = inject('packetStore')(
  observer(class ExpandedText extends Component {
    constructor (props) {
      super(props)
      this.state = { expand: false }
    }

    render () {
      const { Expanded, Text, packet, GoldText } = this.props.packetStore
      const { expand } = this.state
      const { hw } = this.props
      return (
        <>
          <section className={expandedText()}>
            <div
              className={expandedText('container')} style={{ height: expand ? hw : 200, overflowY: expand ? 'overlay' : 'hidden' }}
              dangerouslySetInnerHTML={{ __html: packet < 4 ? Text : GoldText }}
            />
            {Expanded ? <span
              style={expand ? { transform: 'rotate(180deg)' } : {}}
              className={expandedText('expand-button')}
              onClick={() => this.setState({ expand: !expand })}
                        >↓
            </span> : ''}
          </section>
        </>)
    }
  }))

export default ExpandedText
