import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './head.scss'
import 'hamburgers/_sass/hamburgers/hamburgers.scss'
import call from './media/call.svg'
import logo from './media/logodeks.svg'
import { Link } from 'react-router-dom'

class Header extends Component {
  constructor (props) {
    super(props)
    this.onChangePage = this.onChangePage.bind(this)
    this.state = { page: 1 }
  }

  onChangePage (e) {
    console.log(e.target.name)
    this.setState({ page: e.target.name })
  }

  render () {
    const header = cn('header')
    const { page } = this.state
    console.log(typeof page)
    return (
      <header className={header('desktop')}>
        <div className='container'>
          <img src={logo} alt='Логотип комании "Код чистоты' />
          <nav className='menu-desktop'>
            <div className={page == 1 ? 'active' : ''}><Link
              name='1'
              to='/' onClick={this.onChangePage}
            >Главная
            </Link>
            </div>
            <div className={page == 2 ? 'active' : ''}><Link
              onClick={this.onChangePage}
              name='2'
              to='/flat'
            >Квартира
            </Link>
            </div>
            <div className={page == 3 ? 'active' : ''}><Link
              onClick={this.onChangePage}
              name='3'
              to='/office'
            >Офис
            </Link>
            </div>
            <div className={page == 4 ? 'active' : ''}><Link
              onClick={this.onChangePage}
              name='4'
              to='/home'
            >Дом
            </Link>
            </div>
            <div className={page == 5 ? 'active' : ''}><Link
              onClick={this.onChangePage}
              name='5'
              to='/garden'
            >Участок
            </Link>
            </div>
            <div className={page == 6 ? 'active' : ''}><Link
              onClick={this.onChangePage}
              name='6'
              to='/contacts'
            >Контакты
            </Link>
            </div>
          </nav>
          <div className={header('button-block')}>
            <div className={header('phone-block')}>
              <img src={call} alt='Номер телефона' />
              <div>562-506</div>
            </div>
            <button className={header('call-button')}>Заказать звонок</button>
          </div>
        </div>
      </header>
    )
  }
}

export default Header
