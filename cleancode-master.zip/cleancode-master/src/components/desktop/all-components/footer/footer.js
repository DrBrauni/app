import React from 'react'
import { cn } from '@bem-react/classname'
import './footer.scss'
import vk from './media/vk.svg'
import instagram from './media/inst.svg'

const footer = cn('footer-desktop')

export default function Footer () {
  return (
    <>
      <footer className={footer()}>
        <div
          className={footer('up')} onClick={() => window.scrollTo({
            top: 0,
            behavior: 'smooth'
          })}
        >Наверх ↑
        </div>
        <div className={footer('container')}>
          <div>
            <div>Главная</div>
            <div>Тарифы</div>
            <div>Калькулятор</div>
          </div>
          <div>
            <div>Контакты</div>
            <div>О компании</div>
            <div>Акции</div>
          </div>
          <div>
            <div>Уборка домов</div>
            <div>Уборка офисов</div>
            <div>Уборка квартиры</div>
          </div>
          <div>
            <div>Наши преимущества</div>
            <div>Обслуживание участка</div>
            <div>Дополнительные услуги</div>
          </div>
          <div className='text-right'>
            <div><b>+7 (3412) 562-506</b></div>
            <div><b>Звоните с 8:00 до 19:00</b></div>
            <div>Мы в соц. сетях: <img src={vk} /><img src={instagram} /></div>
          </div>
        </div>
        <div className={footer('latest-container')}>
          <div className='gray underline'>Пользовательское соглашение</div>
          <div className='flex-box'>
            <div>г. Ижевск</div>
            <div>ул. Пушкинская, дом 163, офис 323</div>
          </div>
          <div className='gray'>ИП КОД ЧИСТОТЫ ОГРН 25245238452154-1295</div>
        </div>
      </footer>
    </>)
}
