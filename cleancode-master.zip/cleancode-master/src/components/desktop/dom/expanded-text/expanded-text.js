import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './expanded-text.scss'
import { inject, observer } from 'mobx-react'

const expandedText = cn('expanded-text-desktop-dom')

class ExpandedText extends Component {
  constructor (props) {
    super(props)
    this.state = { expand: false }
  }

  render () {
    const { expand } = this.state
    const { text, expanded, num } = this.props
    console.log(num)
    return (
      <>
        <section className={expandedText()}>
          <div className={!expand ? expandedText('container') : expandedText('container', { type: 'expanded' + '_' + num })} dangerouslySetInnerHTML={{ __html: text }} />
          {expanded ? <span style={expand ? { transform: 'rotate(180deg)' } : {}} className={expandedText('expand-button')} onClick={() => this.setState({ expand: !expand })}>↓</span> : ''}
        </section>
      </>)
  }
}

export default ExpandedText
