import React from 'react'
import { SectionName } from '../../mobile/utils-component/section-name/section-name'
import Content from './first/first.js'

export function HomeDesktop () {
  return (<>
    <SectionName
      text='Уборка домов и коттеджей в Ижевске'
      full_width font={30} top={0}
    />
    <Content />

  </>)
}
