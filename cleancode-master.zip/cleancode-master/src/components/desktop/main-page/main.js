import React, { useState } from 'react'
import { Slideshow } from './block_1/block_1'
import { SecondSlideShow } from './block_2/block_2'
import ThirdSlideShow from './block_3/block_3'
import FiveSection from './block_4/block_4'
import SixSection from './block_5/block_5'
import { SevenSection } from './block_6/block_6'
import { EightSection } from './block_7/block_7'
import { Provider } from 'mobx-react'
import packetStore from '../../store/packet_store'
import stepStore from '../../store/step_store'

export function MainPageDesktop () {
  return (<>
    <div className='main-container'>
      <Slideshow />
      <SecondSlideShow />
      <Provider packetStore={packetStore}><ThirdSlideShow /></Provider>
      <Provider packetStore={packetStore}><FiveSection /></Provider>
      <Provider stepStore={stepStore}><SixSection /></Provider>
      <SevenSection />
      <EightSection />
    </div>
          </>)
}
