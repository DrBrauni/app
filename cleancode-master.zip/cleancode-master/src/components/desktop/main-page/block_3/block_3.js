import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './block_3.scss'
import { SectionName } from '../../../mobile/utils-component/section-name/section-name'
import { observer, inject } from 'mobx-react'
import packetStore from '../../../store/packet_store'

const thirdSlideshow = cn('block_3-desktop')

const Slide = inject('packetStore')(
  observer(class Slide extends Component {
    render () {
      return (
        <>
          <div
            onClick={() => this.props.packetStore.setPacket(this.props.name)}
            className={thirdSlideshow('slide', { active: this.props.active })}
          >
            <div className={thirdSlideshow('text')}>{this.props.text}</div>
          </div>
        </>
      )
    }
  }))

const ThirdSlideShow = inject('packetStore')(
  observer(class ThirdSlideShow extends Component {
    render () {
      console.log(this.props)
      const packet = this.props.packetStore.packet
      return (
        <>
          <SectionName
            text='Выберите подходящий тариф для уборки' top={10} font
            font_size={40}
          />
          <section className={thirdSlideshow()}>
            <div className={thirdSlideshow('container')}>
              <Slide
                text={'Могу\nпозволить'} active={packet === 1}
                name={1}
              />
              <Slide
                text={'Пора\nотдохнуть'} active={packet === 2}
                name={2}
              />
              <Slide text={'Всё и\nсразу'} active={packet === 3} name={3} />
              <Slide text={'Золотой\nпакет'} active={packet === 4} name={4} />
            </div>
          </section>
        </>)
    }
  }))

export default ThirdSlideShow
