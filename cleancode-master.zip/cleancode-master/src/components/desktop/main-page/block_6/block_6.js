import React from 'react'
import { cn } from '@bem-react/classname'
import './block_6.scss'
import { SectionName } from '../../../mobile/utils-component/section-name/section-name'
import CleanCode from './media/cleancode.png'

const sevenSection = cn('block_6-desktop')
const expandedText = cn('expanded-text-seven')

export function SevenSection () {
  return (
    <div className={sevenSection()}>
      <SectionName font font_size={40} text={'О компании <q>Код чистоты</q>'} />
      <section className={expandedText()}>
        <img src={CleanCode} className={sevenSection('photo')} />
        <div className={expandedText('container')}>
          <div className={expandedText('text')}>
                Наша компания занимается тем что чистит полы, а ещё иногда стены, бытовую технику, потолки,
                выключатели, рамы, телевизоры, руки, батуты, мячики и другие вещи, моют абсолютно все, не уставая ни
                капельки вот такие они молодцы, а ...
          </div>
        </div>
      </section>
    </div>)
}
