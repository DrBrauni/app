import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './block_4.scss'
import time from './media/time.svg'
import people from './media/woman.svg'
import image from './media/Promokod.png'
import ExpandedText from '../../all-components/expanded-text/expanded-text'
import { inject, observer } from 'mobx-react'

const fiveSection = cn('block_4-desktop')

const FiveSection = inject('packetStore')(
  observer(class FiveSection extends Component {
    render () {
      const { Cost, Time, People, Gift, packet } = this.props.packetStore
      return (
        <>
          <section className={fiveSection()}>
            <img src={image} className='left-image' />
            <div className={fiveSection('container')}>
              <div className={fiveSection('container-head')}>
                {packet < 4 ? <>
                  <div
                    className={this.props.packetStore.subpacket === 1
                      ? 'active'
                      : ''} onClick={() => this.props.packetStore.setSubPacket(
                      1)}
                  >Кухня
                  </div>
                  <div
                    className={this.props.packetStore.subpacket === 2
                      ? 'active'
                      : ''} onClick={() => this.props.packetStore.setSubPacket(
                      2)}
                  >Комната
                  </div>
                  <div
                    className={this.props.packetStore.subpacket === 3
                      ? 'active'
                      : ''} onClick={() => this.props.packetStore.setSubPacket(
                      3)}
                  >Ванная
                  </div>
                </> : <div style={{ fontWeight: 600, color: 'black' }}>Для кого подходит?</div>}
              </div>
              {packet < 4 ? <ExpandedText hw={440} /> : <ExpandedText hw={466} />}
              <div className={fiveSection('cost-block', { type: 'first' })}>
                {packet < 4 ? <>
                  <div>1 комната</div>
                  <div>{Cost[0]}р</div>
                              </> : <>
                  <div>Поддерживающая</div>
                  <div>{Cost[0]} м<sup>2</sup></div>
                      </>}
              </div>
              <div className={fiveSection('cost-block')}>
                {packet < 4 ? <>
                  <div>2 комнаты</div>
                  <div>{Cost[1]}р</div>
                              </> : <>
                  <div>Генеральная</div>
                  <div>{Cost[1]} м<sup>2</sup></div>
                      </>}
              </div>
              <div className={fiveSection('cost-block')}>
                {packet < 4 ? <>
                  <div>3 комнаты</div>
                  <div>{Cost[2]}р</div>
                              </> : <>
                  <div>Уборка после ремонта без мебели</div>
                  <div>{Cost[2]} м<sup>2</sup></div>
                      </>}
              </div>
              <div className={fiveSection('cost-block')}>
                {packet < 4 ? <>
                  <div>70-90 м<sup>2</sup></div>
                  <div>{Cost[3]}р</div>
                              </> : <>
                  <div>Уборка после ремонта c мебелью</div>
                  <div>{Cost[3]} м<sup>2</sup></div>
                      </>}

              </div>
              <div className={fiveSection('additional')}>
                <div className={fiveSection('additional-info')}>
                  <div><img src={time} alt='Время уборки' />{Time}ч</div>
                  <div><img
                    src={people} alt='Количество человек'
                    className={fiveSection('woman')}
                       />{People}
                  </div>
                </div>
              </div>
              <div className={fiveSection('gift')}>
                <div>Подарок: {Gift}</div>
              </div>
              <button className={fiveSection('button')}>Заказать</button>
            </div>
          </section>
        </>)
    }
  }))

export default FiveSection
