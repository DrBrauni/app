import React from 'react'
import { cn } from '@bem-react/classname'
import './step1-2.scss'
import { inject, observer } from 'mobx-react'

const step12 = cn('step12-desktop')

function StepHead () {
  return (
    <div className={step12('header')}>
      <div className={step12('step-head')} />
      <div className={step12('step-subhead', { type: 'not-head' })}>Выберите объем работы</div>
    </div>
  )
}

const StepContent = inject('stepStore')(
  observer(function StepContent (props) {
    const { id } = props.stepStore.step.workset
    const arr = ['1 комната', '2 комнаты', '3 комнаты', 'от 70 до 90 кв.м']
    return (
      <div className={step12('content')}>
        {arr.map((value, index) => {
          return <div
            key={index}
            className={`${id === index ? step12('active') : ''} ${props.stepStore.step.packet.id === 3 || props.stepStore.step.packet.id === -1 ? step12('disable') : ''}`}
            onClick={!(props.stepStore.step.packet.id === 3 || props.stepStore.step.packet.id === -1) ? () => props.stepStore.setWorkSet(index, value) : () => {}}
                 >{value}
                 </div>
        })}
        <div className={step12('active')} onClick={() => props.stepStore.nextStep()}>Далее</div>
      </div>
    )
  }))

export function Step2 () {
  return (
    <div className={step12('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
