import React from 'react'
import { cn } from '@bem-react/classname'
import './step3.scss'
import * as Swal from 'sweetalert2'
import { inject, observer } from 'mobx-react'

const step3 = cn('step3-desktop')

function StepHead () {
  return (
    <div className={step3('header')}>
      <div className={step3('step-head')} />
      <div className={step3('step-subhead', { type: 'not-head' })}>
        Итоговая стоимость
      </div>
    </div>
  )
}
const sendData = () => {
  Swal.fire({
    type: 'success',
    title: 'Заказ успешно отправлен',
    text: 'Скоро с вами свяжется оператор'
  })
}
function stepContent (props) {
  return (
    <div className={step3('content')}>
      <div className={step3('total_cost')}>{props.stepStore.TotalCost} <span>рублей</span></div>
      <div className={step3('advice')}>Оформите заявку сейчас</div>
      <form className={step3('form')}>
        <div className={step3('form-input')}>
          <label>
            <input
              required
            />
            <span className='placeholder'>Введите ваше имя</span>
          </label>
        </div>
        <div className={step3('form-input')}>
          <label>
            <input required /><span className='placeholder'>Введите ваш телефон</span>
          </label>
        </div>
      </form>
      <div className={step3('active')} onClick={() => sendData()}>Заказать уборку</div>
      <div className={step3('small-advice')}>Нажимая кнопку «Заказать уборку», Вы соглашаетесь с условиями по обработке персональных данных в политике конфидициальности</div>
    </div>
  )
}

const StepContent = inject('stepStore')(observer(stepContent))

export function Step3 () {
  return (
    <div className={step3('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
