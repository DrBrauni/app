import React from 'react'
import { cn } from '@bem-react/classname'
import './step2-1.scss'
import { inject, observer } from 'mobx-react'

const step21 = cn('step21-desktop')

function StepHead () {
  return (
    <div className={step21('header')}>
      <div className={step21('step-head')}>Шаг 2</div>
      <div className={step21('step-subhead')}>Выберите доп. услуги</div>
    </div>
  )
}

const StepContent = inject('stepStore')(
  observer(function StepContent (props) {
    const step_text = [
      { text: 'Уборка балкона', max: 5, cost: 200 },
      { text: 'Мойка балкона', max: 5, cost: 800 },
      { text: 'Доп. сотрудник', max: 5, cost: 1000 },
      { text: 'Дети дома', max: 5, cost: 990 }]
    const { step: stepData } = props.stepStore
    const step = '1'
    console.log(props.stepStore.step)
    console.log(props.stepStore.step[step_text[0]])
    if (props.stepStore.step[`${step}_${0}`] === undefined) {
      for (const i in step_text) {
        props.stepStore.step[`${step}_${i}`] = { count: 0, cost: 0 }
      }
    }
    console.log(props.stepStore)
    return (
      <div className={step21('content')}>
        {step_text.map((value, index) => {
          return (<div className={step21('counter')} key={index}>
            <div
              className='minus' name={`${step}_${index}`}
              onClick={() => props.stepStore.minusValue(`${step}_${index}`, value.cost, value.text)}
            >-
            </div>
            <div className='content' name={`${step}_${index}`}>
              <div className='name'>{value.text}</div>
              <div className='count'>{stepData[`${step}_${index}`].count || 0}</div>
            </div>
            <div
              className='plus' name={`${step}_${index}`}
              onClick={() => props.stepStore.plusValue(`${step}_${index}`, value.cost, value.max, value.text)}
            >+
            </div>
                  </div>)
        })}
        <div onClick={() => props.stepStore.prevStep()} className={step21('active')}>Назад</div>
      </div>
    )
  }))

export function Step21 () {
  return (
    <div className={step21('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
