import React from 'react'
import { cn } from '@bem-react/classname'
import './step2-4.scss'
import { inject, observer } from 'mobx-react'

const step24 = cn('step24-desktop')

function StepHead () {
  return (
    <div className={step24('header')}>
      <div className={step24('step-head')} />
      <div className={step24('step-subhead', { type: 'not-head' })}>Химчистка матрасов</div>
    </div>
  )
}

const StepContent = inject('stepStore')(
  observer(function StepContent (props) {
    const step_text = [
      { text: 'Односпальный', max: 5, cost: 700 },
      { text: 'Полутроспальный', max: 5, cost: 1000 },
      { text: 'Двуспальный', max: 5, cost: 1300 },
      { text: 'Детский', max: 5, cost: 500 }]
    const { step: stepData } = props.stepStore
    const step = '4'
    console.log(props.stepStore.step)
    console.log(props.stepStore.step[step_text[0]])
    if (props.stepStore.step[`${step}_${0}`] === undefined) {
      for (const i in step_text) {
        props.stepStore.step[`${step}_${i}`] = { count: 0, cost: 0 }
      }
    }
    console.log(props.stepStore)
    return (
      <div className={step24('content')}>
        {step_text.map((value, index) => {
          return (<div className={step24('counter')} key={index}>
            <div
              className='minus' name={`${step}_${index}`}
              onClick={() => props.stepStore.minusValue(`${step}_${index}`, value.cost, value.text)}
            >-
            </div>
            <div className='content' name={`${step}_${index}`}>
              <div className='name'>{value.text}</div>
              <div className='count'>{stepData[`${step}_${index}`].count || 0}</div>
            </div>
            <div
              className='plus' name={`${step}_${index}`}
              onClick={() => props.stepStore.plusValue(`${step}_${index}`, value.cost, value.max, value.text)}
            >+
            </div>
                  </div>)
        })}
        <div onClick={() => props.stepStore.nextStep()} className={step24('active')}>Далее</div>
      </div>
    )
  }))

export function Step24 () {
  return (
    <div className={step24('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
