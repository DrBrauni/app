import React from 'react'
import { cn } from '@bem-react/classname'
import './step2-2.scss'
import { inject, observer } from 'mobx-react'

const step22 = cn('step22-desktop')

function StepHead () {
  return (
    <div className={step22('header')}>
      <div className={step22('step-head')} />
      <div className={step22('step-subhead', { type: 'not-head' })}>Выберите
        доп. услуги
      </div>
    </div>
  )
}

const StepContent = inject('stepStore')(
  observer(function StepContent (props) {
    const step_text = [
      { text: 'Мытьё посуды', max: 5, cost: 150 },
      { text: 'Помывка окон', max: 10, cost: 150 },
      { text: 'Глажка белья', max: 5, cost: 350 },
      { text: 'Уборка снега', max: 10, cost: 400 }]
    const { step: stepData } = props.stepStore
    const step = '2'
    console.log(props.stepStore.step)
    console.log(props.stepStore.step[step_text[0]])
    if (props.stepStore.step[`${step}_${0}`] === undefined) {
      for (const i in step_text) {
        props.stepStore.step[`${step}_${i}`] = { count: 0, cost: 0 }
      }
    }
    console.log(props.stepStore)
    return (
      <div className={step22('content')}>
        {step_text.map((value, index) => {
          return (<div className={step22('counter')} key={index}>
            <div
              className='minus' name={`${step}_${index}`}
              onClick={() => props.stepStore.minusValue(`${step}_${index}`, value.cost, value.text)}
            >-
            </div>
            <div className='content' name={`${step}_${index}`}>
              <div className='name'>{value.text}</div>
              <div className='count'>{stepData[`${step}_${index}`].count || 0}</div>
            </div>
            <div
              className='plus' name={`${step}_${index}`}
              onClick={() => props.stepStore.plusValue(`${step}_${index}`, value.cost, value.max, value.text)}
            >+
            </div>
          </div>)
        })}
        <div onClick={() => props.stepStore.nextStep()} className={step22('active')}>Далее</div>
      </div>
    )
  }))

export function Step22 () {
  return (
    <div className={step22('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
