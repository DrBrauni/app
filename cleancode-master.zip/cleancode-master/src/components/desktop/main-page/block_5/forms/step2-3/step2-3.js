import React from 'react'
import { cn } from '@bem-react/classname'
import './step2-3.scss'
import { inject, observer } from 'mobx-react'

const step23 = cn('step23-desktop')

function StepHead () {
  return (
    <div className={step23('header')}>
      <div className={step23('step-head')} />
      <div className={step23('step-subhead', { type: 'not-head' })}>Мойка бытовой техники</div>
    </div>
  )
}

const StepContent = inject('stepStore')(
  observer(function StepContent (props) {
    const step_text = [
      { text: 'Холодильник', max: 5, cost: 350 },
      { text: 'Духовой шкаф', max: 5, cost: 350 },
      { text: 'Микроволновка', max: 5, cost: 180 },
      { text: 'Посудомойка', max: 5, cost: 350 }]
    const { step: stepData } = props.stepStore
    const step = '3'
    console.log(props.stepStore.step)
    console.log(props.stepStore.step[step_text[0]])
    if (props.stepStore.step[`${step}_${0}`] === undefined) {
      for (const i in step_text) {
        props.stepStore.step[`${step}_${i}`] = { count: 0, cost: 0 }
      }
    }
    console.log(props.stepStore)
    return (
      <div className={step23('content')}>
        {step_text.map((value, index) => {
          return (<div className={step23('counter')} key={index}>
            <div
              className='minus' name={`${step}_${index}`}
              onClick={() => props.stepStore.minusValue(`${step}_${index}`, value.cost, value.text)}
            >-
            </div>
            <div className='content' name={`${step}_${index}`}>
              <div className='name'>{value.text}</div>
              <div className='count'>{stepData[`${step}_${index}`].count || 0}</div>
            </div>
            <div
              className='plus' name={`${step}_${index}`}
              onClick={() => props.stepStore.plusValue(`${step}_${index}`, value.cost, value.max, value.text)}
            >+
            </div>
          </div>)
        })}
        <div onClick={() => props.stepStore.prevStep()} className={step23('active')}>Назад</div>
      </div>
    )
  }))

export function Step23 () {
  return (
    <div className={step23('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
