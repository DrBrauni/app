import React from 'react'
import { cn } from '@bem-react/classname'
import './step1.scss'
import { inject, observer } from 'mobx-react'

const step1 = cn('step1-desktop')

function StepHead () {
  return (
    <div className={step1('header')}>
      <div className={step1('step-head')}>Шаг 1</div>
      <div className={step1('step-subhead')}>Выберите пакет</div>
    </div>
  )
}

const StepContent = inject('stepStore')(
  observer(function StepContent (props) {
    const { id } = props.stepStore.step.packet
    return (
      <div className={step1('content')}>
        <div
          className={id === 0 ? step1('active') : ''}
          onClick={() => props.stepStore.setPacket(0, 'Могу позволить')}
        >Могу позволить
        </div>
        <div
          className={id === 1 ? step1('active') : ''}
          onClick={() => props.stepStore.setPacket(1, 'Пора отдохнуть')}
        >Пора отдохнуть
        </div>
        <div
          className={id === 2 ? step1('active') : ''}
          onClick={() => props.stepStore.setPacket(2, 'Всё и сразу!')}
        >Всё и сразу!
        </div>
        <div
          className={id === 3 ? step1('active') : ''}
          onClick={() => props.stepStore.setPacket(3, 'Без пакета')}
        >Без пакета
        </div>
      </div>
    )
  }))

export function Step1 () {
  return (
    <div className={step1('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
