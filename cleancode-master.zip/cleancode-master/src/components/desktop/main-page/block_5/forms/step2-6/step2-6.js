import React from 'react'
import { cn } from '@bem-react/classname'
import './step2-6.scss'
import { inject, observer } from 'mobx-react'

const step26 = cn('step26-desktop')

function StepHead () {
  return (
    <div className={step26('header')}>
      <div className={step26('step-head')} />
      <div className={step26('step-subhead', { type: 'not-head' })}>
        {'Введите промокод, чтобы\nузнать стоимость со скидкой.\nЕсли вы не знаете промокод,\nто просто нажмите кнопку\n«Узнать результат»'}
      </div>
    </div>
  )
}

const StepContent = inject('stepStore')(
  observer(function StepContent (props) {
    return (
      <div className={step26('content')}>
        <form className={step26('form')}>
          <div className={step26('form-input')}>
            <label>
              <input />
              <span className='placeholder'>Промокод</span>
            </label>
          </div>
        </form>
        <div onClick={() => props.stepStore.nextStep()} className={step26('active')}>Узнать результат</div>
      </div>
    )
  }))

export function Step26 () {
  return (
    <div className={step26('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
