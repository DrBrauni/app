import React from 'react'
import { cn } from '@bem-react/classname'
import './step2-5.scss'
import { inject, observer } from 'mobx-react'

const step25 = cn('step25-desktop')

function StepHead () {
  return (
    <div className={step25('header')}>
      <div className={step25('step-head')} />
      <div className={step25('step-subhead', { type: 'not-head' })}>Химчистка диванов</div>
    </div>
  )
}

const StepContent = inject('stepStore')(
  observer(function StepContent (props) {
    const step_text = [
      { text: 'Угловой', max: 5, cost: 1500 },
      { text: 'Прямой', max: 5, cost: 1200 },
      { text: 'Мини', max: 5, cost: 800 },
      { text: 'Кресло', max: 5, cost: 500 }]
    const { step: stepData } = props.stepStore
    const step = '5'
    console.log(props.stepStore.step)
    console.log(props.stepStore.step[step_text[0]])
    if (props.stepStore.step[`${step}_${0}`] === undefined) {
      for (const i in step_text) {
        props.stepStore.step[`${step}_${i}`] = { count: 0, cost: 0 }
      }
    }
    console.log(props.stepStore)
    return (
      <div className={step25('content')}>
        {step_text.map((value, index) => {
          return (<div className={step25('counter')} key={index}>
            <div
              className='minus' name={`${step}_${index}`}
              onClick={() => props.stepStore.minusValue(`${step}_${index}`, value.cost, value.text)}
            >-
            </div>
            <div className='content' name={`${step}_${index}`}>
              <div className='name'>{value.text}</div>
              <div className='count'>{stepData[`${step}_${index}`].count || 0}</div>
            </div>
            <div
              className='plus' name={`${step}_${index}`}
              onClick={() => props.stepStore.plusValue(`${step}_${index}`, value.cost, value.max, value.text)}
            >+
            </div>
          </div>)
        })}
        <div onClick={() => props.stepStore.prevStep()} className={step25('active')}>Назад</div>
      </div>
    )
  }))

export function Step25 () {
  return (
    <div className={step25('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
