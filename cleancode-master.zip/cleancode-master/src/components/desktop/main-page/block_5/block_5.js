
import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './block_5.scss'
import { Step1 } from './forms/step1/step1'
import { SectionName } from '../../../mobile/utils-component/section-name/section-name'
import { Step2 } from './forms/step1-2/step1-2'
import { Step22 } from './forms/step2-2/step2-2'
import { Step21 } from './forms/step2-1/step2-1'
import { Step23 } from './forms/step2-3/step2-3'
import { Step24 } from './forms/step2-4/step2-4'
import { Step25 } from './forms/step2-5/step2-5'
import { inject, observer } from 'mobx-react'
import { Step26 } from './forms/step2-6/step2-6'
import { Step3 } from './forms/step3/step3'

const sixSection = cn('block_5-desktop')

const SixSection = inject('stepStore')(
  observer(class SixSection extends Component {
    render () {
      console.log(this.props)
      const { cur_step } = this.props.stepStore
      return (
        <div className={sixSection()}>
          <SectionName
            full_width
            font font_size={30} top={20}
            text='Воспользуйстесь калькулятором чтобы рассчитать стоимость уборки'
          />
          <section className={sixSection('steps')}>
            {cur_step === 1 ? <><Step1 /><Step2 /></> : ''}
            {cur_step === 2 ? <><Step21 /><Step22 /></> : ''}
            {cur_step === 3 ? <><Step23 /><Step24 /></> : ''}
            {cur_step === 4 ? <><Step25 /><Step26 /></> : ''}
            {cur_step === 5 ? <Step3 /> : ''}
          </section>
        </div>)
    }
  }))

export default SixSection
