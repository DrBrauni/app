import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './block_1.scss'
import Carousel from 'antd/lib/carousel/index'

const slideshow = cn('block_1-desktop')

function Slide () {
  return (
    <div className={slideshow('slide', { type: 'main' })}>
      <div className={slideshow('slide', { type: 'content' })}>
        <h1 className={slideshow('slide', { type: 'head' })}>Профессиональный и доступный клининг для вашей
                квартиры
        </h1>
        <h2 className={slideshow('slide', { type: 'subhead' })}>
            Клининговая компания «Код чистоты»
            в Ижевске имеет обширный список
            услуг для выбора каждого клиента
        </h2>
        <h3 className={slideshow('slide', { type: 'subsubhead' })}>
              Воспользуйся нашими готовыми пакетами, а
              то самому выбирать как то там сложно
        </h3>
        <button className={slideshow('slide', { type: 'button' })}>Подобрать выгодный тариф</button>
      </div>
    </div>
  )
}

export class Slideshow extends Component {
  constructor (props) {
    super(props)
    this.next = this.next.bind(this)
    this.previous = this.previous.bind(this)
    this.carousel = React.createRef()
  }

  next () {
    this.carousel.next()
  }

  previous () {
    this.carousel.prev()
  }

  render () {
    return (
      <section className={slideshow()}>
        <Carousel className={slideshow('carousel')} ref={node => (this.carousel = node)}>
          <Slide />
          <Slide />
          <Slide />
          <Slide />
          <Slide />
        </Carousel>
        <div className='slide-right no-select' onClick={this.next}>→</div>
        <div className='slide-left no-select' onClick={this.previous}>←</div>
      </section>)
  }
}
