import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './block_2.scss'
import brush from './media/brush.svg'
import brush2 from './media/brush2.svg'
import bucket from './media/bucket.svg'
import charwoman from './media/charwoman.svg'
import eco from './media/eco.svg'
import { SectionName } from '../../../mobile/utils-component/section-name/section-name'

const secondSlideshow = cn('block_2-desktop')

function Slide (props) {
  return (
    <>
      <div className={secondSlideshow('slide', { position: props.position })}>
        <div className={secondSlideshow('text')}>{props.text}</div>
        <img className={secondSlideshow('image')} src={props.image} alt={props.text} />
      </div>
    </>
  )
}

export class SecondSlideShow extends Component {
  render () {
    return (
      <>
        <SectionName top={40} text='Почему стоит обратиться именно к нам?' font font_size={40} />
        <section className={secondSlideshow({ type: 'desktop' })}>
          <div className={secondSlideshow('container')}>
            <Slide position='top' image={bucket} text={'Фиксированная стоимость \n услуг'} />
            <Slide position='bottom' image={brush} text={'Обширный спектр \n услуг'} />
            <Slide position='top' image={eco} text={'Экологически \n чистые \n средства'} />
            <Slide position='bottom' image={brush2} text={'Оставляйте заявку в \n любое время'} />
            <Slide position='top' image={charwoman} text='Только обученный персонал' />
          </div>
        </section>
      </>)
  }
}
