import React, { useState } from 'react'
import { cn } from '@bem-react/classname'
import './block_7.scss'
import { SectionName } from '../../../mobile/utils-component/section-name/section-name'

const eightsection = cn('block_7-desktop')

function Slide (props) {
  return (
    <>
      <div className={eightsection('slide', { active: props.active })}>
        <div className={eightsection('text')}>{props.text}</div>
      </div>
    </>
  )
}

export function EightSection () {
  return (
    <div className={eightsection()}>
      <SectionName
        text='Оформи заявку на обратный звонок ' font
        font_size={40}
      />
      <section className={eightsection('main-container')}>
        <div className={eightsection('left')}>
          <div className={eightsection('left', { type: 'head' })}>
            При заказе с сайта вы получите скидку 10%
            на любую дополнительную услугу
          </div>
          <div className={eightsection('left', { type: 'subhead' })}>
            Выбери пакет, о котором вы хотите узнать информацию:
          </div>
          <div className={eightsection('slide-container')}>
            <Slide text={'Могу \n позволить'} active />
            <Slide text={'Пора \n отдохнуть'} />
            <Slide text={'Всё и \n сразу'} />
            <Slide text={'Золотой \n пакет'} />
          </div>
        </div>
        <div className={eightsection('container')}>
          <div
            className={eightsection('advice')}
          >Заполните
            данные
          </div>
          <form className={eightsection('form')}>
            <div className={eightsection('form-input')}>
              <label>
                <input
                  required
                />
                <span className='placeholder'>Введите ваше имя</span>
              </label>
            </div>
            <div className={eightsection('form-input')}>
              <label>
                <input required /><span className='placeholder'>Введите ваш телефон</span>
              </label>
            </div>
          </form>
          <button className={eightsection('button')}>Заказать</button>
          <div className={eightsection('small-advice')}>Нажимая кнопку
            «Заказать», Вы принимаете <a>соглашение на обработку персональных данных </a>
          </div>
        </div>
      </section>
    </div>)
}
