import { action, computed, decorate, observable } from 'mobx'

class Step {
    step = {
      packet: {
        id: -1,
        text: ''
      },
      workset: {
        id: -1,
        text: ''
      }
    }

    cur_step = 1

    minusValue (name, cost, text) {
      if (this.step[name].count > 0) {
        this.step[name] = { count: this.step[name].count - 1, cost: cost, text: text }
      }
    }

    plusValue (name, cost, max, text) {
      if (this.step[name].count < max) {
        this.step[name] = { count: this.step[name].count + 1, cost: cost, text: text }
      }
    }

    setPacket (id, name) {
      this.step.packet = { id: id, text: name }
      console.log(id, name)
      if (id === 3) {
        this.step.workset = { id: -1, text: '', cost: 0 }
      }
    }

    setWorkSet (id, name) {
      const cost_arr = [[990, 1290, 1490, 1890], [1390, 1790, 2000, 2690], [2000, 3490, 5000, 7490], [0, 0, 0, 0]]
      this.step.workset = { id: id, text: name, cost: cost_arr[this.step.packet.id][id] }
    }

    nextStep (max, cost) {
      this.cur_step += 1
    }

    prevStep () {
      this.cur_step -= 1
    }

    get Values () {
      console.log(this.step)
      return this.step
    }

    get TotalCost () {
      let cost = 0
      console.log(this.step)
      console.log(this.step['1_0'])
      const a = ['1', '2', '3', '4', '5']
      const b = [0, 1, 2, 3]
      for (const i of a) {
        for (const j of b) {
          cost += this.step[`${i}_${j}`].cost * this.step[`${i}_${j}`].count
        }
      }
      cost += this.step.workset.cost
      return cost
      // for (const i of this.step) {
      //   console.log(i)
      //   cost += i.cost * i.value
      // }
    }
}

decorate(Step, {
  step: observable,
  cur_step: observable,
  setValue: action,
  minusValue: action,
  plusValue: action,
  nextStep: action,
  prevStep: action,
  setPacket: action,
  setWorkSet: action,
  Values: computed,
  TotalCost: computed
})

const stepStore = new Step()

export default stepStore
