import React from 'react'
import { cn } from '@bem-react/classname'
import './block_3.scss'
import { SectionName } from '../../utils-component/section-name/section-name'
import { ExpandedText } from '../../utils-component/expanded-text/expanded-text'

const block_3 = cn('block_3-mobile')

function Slide (props) {
  return (
    <>
      <div className={block_3('slide', { active: props.active })}>
        <div className={block_3('text')}>{props.text}</div>
      </div>
    </>
  )
}

export function ThirdSlideShow () {
  return (
    <>
      <SectionName text='Выберите подходящий тариф для уборки' top={30} />
      <section className={block_3()}>
        <div className={block_3('container')}>
          <Slide text={'Могу \n позволить'} active />
          <Slide text={'Пора \n отдохнуть'} />
          <Slide text={'Всё и \n сразу'} />
          <Slide text={'Золотой \n пакет'} />
        </div>
      </section>

    </>)
}
