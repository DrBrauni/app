import React from 'react'
import { cn } from '@bem-react/classname'
import { ExpandedText } from '../../utils-component/expanded-text/expanded-text'
import { SectionName } from '../../utils-component/section-name/section-name'

const block_7 = cn('block_7-mobile')

export function SevenSection () {
  return (
    <div className={block_7()}>
      <SectionName top={40} text={'О компании<br /><q>Код чистоты</q>'} />
      <ExpandedText text='Наша компания занимается тем что чистит полы, а ещё иногда стены, бытовую технику, потолки, выключатели, рамы, телевизоры, руки, батуты, мячики и другие вещи, моют абсолютно все, не уставая ни капельки вот такие они молодцы, а ...' />
    </div>)
}
