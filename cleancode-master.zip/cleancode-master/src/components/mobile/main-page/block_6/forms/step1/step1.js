import React from 'react'
import { cn } from '@bem-react/classname'
import './step1.scss'

const step1 = cn('step1')

function StepHead () {
  return (
    <div className={step1('header')}>
      <div className={step1('step-head')}>Шаг 1</div>
      <div className={step1('step-subhead')}>Выберите пакет</div>
    </div>
  )
}

function StepContent () {
  return (
    <div className={step1('content')}>
      <div>Могу позволить</div>
      <div>Пора отдохнуть</div>
      <div>Всё и сразу!</div>
      <div>Золотой пакет</div>
      <div>Без пакета</div>
    </div>
  )
}

export function Step1 () {
  return (
    <div className={step1('container')}>
      <StepHead />
      <StepContent />
    </div>)
}
