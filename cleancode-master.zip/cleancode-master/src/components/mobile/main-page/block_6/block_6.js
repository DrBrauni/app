import React from 'react'
import { cn } from '@bem-react/classname'
import './block_6.scss'
import { Step1 } from './forms/step1/step1'
import { SectionName } from '../../utils-component/section-name/section-name'

const block_6 = cn('block_6-mobile')

export function SixSection () {
  return (
    <div className={block_6()}>
      <SectionName text='Воспользуйстесь калькулятором чтобы рассчитать стоимость уборки' top={30} font_size='5vw' font full_width />
      <section className={block_6('steps')}>
        <Step1 />
      </section>
    </div>)
}
