import React, { useState } from 'react'
import { cn } from '@bem-react/classname'
import './block_8.scss'
import { SectionName } from '../../utils-component/section-name/section-name'

const block_8 = cn('block_8-mobile')

export function EightSection () {
  const [hidden, hid] = useState(true)
  return (
    <div className={block_8()}>
      <SectionName text={'Остались вопросы? <br /> Оставьте заявку на звонок!'} />
      <section className={block_8('container')}>
        <div className={block_8('advice')} style={{ color: hidden ? 'black' : 'white' }}>Заполните данные</div>
        <form className={block_8('form')}>
          <div className={block_8('form-input')}>
            <label>
              <input required onBlur={() => { hid(!hidden) }} onFocus={() => { hid(!hidden) }} />
              <span className='placeholder'>Введите ваше имя</span>
            </label>
          </div>
          <div className={block_8('form-input')}>
            <label>
              <input required /><span className='placeholder'>Введите ваш телефон</span>
            </label>
          </div>
        </form>
        <button className={block_8('button')}>Заказать</button>
        <div className={block_8('small-advice')}>Нажимая кнопку «Заказать», Вы принимаете <a>соглашение на обработку персональных данных</a></div>
      </section>
    </div>)
}
