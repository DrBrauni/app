import React from 'react'
import { cn } from '@bem-react/classname'
import './block_5.scss'
import time from './media/time.svg'
import people from './media/woman.svg'

const block_5 = cn('block_5-mobile')

export function FiveSection () {
  return (
    <>
      <section className={block_5()}>
        <div className={block_5('container')}>
          <div className={block_5('header')}>Стоимость:</div>
          <div className={block_5('cost-block')}>
            <div>1 комната</div>
            <div>990р</div>
          </div>
          <div className={block_5('cost-block')}>
            <div>2 комнаты</div>
            <div>1290р</div>
          </div>
          <div className={block_5('cost-block')}>
            <div>3 комнаты</div>
            <div>1490р</div>
          </div>
          <div className={block_5('cost-block')}>
            <div>70-90 кв.м</div>
            <div>1890р</div>
          </div>
          <div className={block_5('additional')}>
            <div className={block_5('additional-info')}>
              <div><img src={time} alt='Время уборки' />4-7ч</div>
              <div><img src={people} alt='Количество человек' className={block_5('woman')} />1</div>
            </div>
            <div className={block_5('max-height')}>Высота уборки: до 1.8м</div>
          </div>
          <div className={block_5('gift')}>
            <div>Подарок: 1 доп. услуга на выбор</div>
          </div>
        </div>
        <button className={block_5('button')}>Заказать</button>
      </section>
    </>)
}
