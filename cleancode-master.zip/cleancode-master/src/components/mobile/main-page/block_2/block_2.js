import React, { Component } from 'react'
import { cn } from '@bem-react/classname'
import './block_2.scss'
import brush from './media/brush.svg'
import brush2 from './media/brush2.svg'
import bucket from './media/bucket.svg'
import charwoman from './media/charwoman.svg'
import eco from './media/eco.svg'
import { SectionName } from '../../utils-component/section-name/section-name'

const block_2 = cn('block_2-mobile')

function Slide (props) {
  return (
    <>
      <div className={block_2('slide', { position: props.position })}>
        <div className={block_2('text')}>{props.text}</div>
        <img className={block_2('image')} src={props.image} alt={props.text} />
      </div>
    </>
  )
}

export class SecondSlideShow extends Component {
  componentDidMount () {
    document.getElementsByClassName('block_2-mobile')[0].scrollLeft = 236
  }

  render () {
    return (
      <>
        <SectionName top={40} text='Почему стоит обратиться именно к нам?' />
        <section className={block_2()}>
          <div className={block_2('container')}>
            <Slide position='top' image={bucket} text={'Фиксированная стоимость \n услуг'} />
            <Slide position='bottom' image={brush} text={'Обширный спектр \n услуг'} />
            <Slide position='top' image={eco} text='Экологически чистые средства' />
            <Slide position='bottom' image={brush2} text={'Оставляйте заявку в \n любое время'} />
            <Slide position='top' image={charwoman} text='Только обученный персонал' />
          </div>
        </section>
      </>)
  }
}
