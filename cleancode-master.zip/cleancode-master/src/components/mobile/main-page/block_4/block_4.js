import React from 'react'
import { cn } from '@bem-react/classname'
import './block_4.scss'
import { ExpandedText } from '../../utils-component/expanded-text/expanded-text'

const block_4 = cn('block_4-mobile')

export function FourSlideshow () {
  return (
    <>
      <section className={block_4()}>
        <div className={block_4('container')}>
          <div>Кухня</div>
          <div>Комната</div>
          <div>Ванная</div>
        </div>
        <ExpandedText
          text={'<ul><li>Моем холодильник снаружи</li><li>Чистим горизонтальные поверхности</li><li>Моем кухонную плиту и стену над ней</li><li>Чистим и обеззараживаем сантехнику</li><li>Моем мусорную корзину, выносим мусор</li></ul>'}
        />
      </section>
    </>)
}
