import React from 'react'
import { cn } from '@bem-react/classname'
import './block_1.scss'
import Carousel from 'antd/lib/carousel/index'
import 'antd/lib/carousel/style/css'

const block_1 = cn('block_1-mobile')

function Slide () {
  return (
    <div className={block_1('slide', { type: 'main' })}>
      <h1 className={block_1('slide', { type: 'head' })}>Профессиональный и доступный клининг для вашей
                квартиры
      </h1>
      <h2 className={block_1('slide', { type: 'subhead' })}>Клининговая компания «Код чистоты» в Ижевске выполняет
                все виды профессиональной уборки
      </h2>
      <button className={block_1('slide', { type: 'button' })}>Подобрать выгодный тариф</button>
    </div>
  )
}

export function Slideshow () {
  return (
    <section className={block_1()}>
      <Carousel dots={false} className={block_1('carousel')}>
        <Slide />
        <Slide />
      </Carousel>
    </section>)
}
