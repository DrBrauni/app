import React from 'react'
import { Header } from '../all-components/header/head'
import { Slideshow } from './block_1/block_1'
import { SecondSlideShow } from './block_2/block_2'
import { ThirdSlideShow } from './block_3/block_3'
import { FourSlideshow } from './block_4/block_4'
import { FiveSection } from './block_5/block_5'
import { SixSection } from './block_6/block_6'
import { SevenSection } from './block_7/block_7'
import { EightSection } from './block_8/block_8'
import { LastSection } from '../all-components/footer/footer'

export function MainPageMobile () {
  return (<>
    <Header />
    <Slideshow />
    <SecondSlideShow />
    <ThirdSlideShow />
    <FourSlideshow />
    <FiveSection />
    <SixSection />
    <SevenSection />
    <EightSection />
    <LastSection />
          </>)
}
