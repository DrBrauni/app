import React, { useState } from 'react'
import { cn } from '@bem-react/classname'
import './head.scss'
import 'hamburgers/_sass/hamburgers/hamburgers.scss'
import call from './media/call.svg'
import moblogo from './media/logomob.svg'
import { inject, observer } from 'mobx-react'

function menu (props) {
  const menu = cn('menu-mobile')
  const { page } = props.menuStore
  return (
    <nav className={menu()}>
      <div className={menu('content')}>
        <div className={page === 1 ? 'active-page' : ''} onClick={() => props.menuStore.setPage(1)}>Главная</div>
        <div>Калькулятор</div>
        <div className={page === 2 ? 'active-page' : ''} onClick={() => props.menuStore.setPage(2)}>Участок</div>
        <div className={page === 3 ? 'active-page' : ''} onClick={() => props.menuStore.setPage(3)}>Дом</div>
        <div className={page === 4 ? 'active-page' : ''} onClick={() => props.menuStore.setPage(4)}>Офис</div>
        <div className={page === 5 ? 'active-page' : ''} onClick={() => props.menuStore.setPage(5)}>Квартира</div>
        <div className={page === 6 ? 'active-page' : ''} onClick={() => props.menuStore.setPage(6)}>Контакты</div>
        <div>О нас</div>
        <div>Instagram</div>
      </div>
    </nav>
  )
}

const Menu = inject('menuStore')(observer(menu))

export function Header (props) {
  const header = cn('header')
  const [hamburger, openmenu] = useState(false)
  return (
    <>
      <header className='header-mobile'>
        <div className={header('feedback')}><img
          className={header('call')}
          alt='Номер телефона'
          src={call}
        />562-506
        </div>
        <button
          className={`hamburger hamburger--collapse ${hamburger
                        ? 'is-active'
                        : ''}`} type='button'
          onClick={() => openmenu(!hamburger)}
        >
          <span className='hamburger-box'>
            <span className='hamburger-inner' />
          </span>
        </button>

        <img className={header('logo')} src={moblogo} alt='Код чистоты' />
      </header>
      {hamburger ? <Menu num={props.num} /> : ''}
    </>
  )
}
