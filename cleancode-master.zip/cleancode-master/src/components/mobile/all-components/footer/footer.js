import React from 'react'
import { cn } from '@bem-react/classname'
import './footer.scss'
import vk from './media/vk.svg'
import instagram from './media/inst.svg'

const footer = cn('footer-mobile')

export function LastSection () {
  return (
    <>
      <footer className={footer()}>
        <div className='footer-container'>
          <div className={footer('container')}>
            <div className={footer('social')}>
              <img src={instagram} />
              <img src={vk} />
            </div>
            <div
              className={footer('up')} onClick={() => window.scrollTo({
                top: 0,
                behavior: 'smooth'
              })}
            >Наверх ↑
            </div>
          </div>
          <div>
            <div className='contacts'>
              <div>562-506</div>
              <div>8-912-856-25-06</div>
              <div>Звоните с 9:00 до 19:00</div>
              <div>г. Ижевск. неизвестно</div>
            </div>
            <div className='company-info'>
              <div>ИП неизвестно ОГРН неизвестно</div>
              <div className='underline'>Пользовательское соглашение</div>
            </div>
          </div>
        </div>
      </footer>
    </>)
}
