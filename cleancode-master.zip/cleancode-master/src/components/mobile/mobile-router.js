import React, { useState } from 'react'

import { Switch, Route } from 'react-router-dom'
import { inject, observer } from 'mobx-react'
import { MainPageMobile } from './main-page/main'

function mobileRouter (props) {
  console.log(props)
  return (
    <>
      <Switch>
        <Route path='/'>
          <MainPageMobile />
        </Route>
      </Switch>
    </>
  )
}

const MobileRouter = inject('menuStore')(observer(mobileRouter))

export default MobileRouter
