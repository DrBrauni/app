import React from 'react'
import { cn } from '@bem-react/classname'
import './section-name.scss'

export function SectionName (props) {
  const sectionHead = cn('section-head')
  return (
    <div className='transition' style={{ marginTop: props.top }}>
      <h1 className={sectionHead('header')} style={{ width: props.full_width ? '100%' : '80%', fontSize: props.font ? props.font_size : '6vw' }} dangerouslySetInnerHTML={{ __html: props.text }} />
    </div>
  )
}
