import React from 'react'
import { cn } from '@bem-react/classname'
import './expanded-text.scss'

const expandedText = cn('expanded-text')

export function ExpandedText (props) {
  return (
    <section className={expandedText()}>
      <div className={expandedText('container')} dangerouslySetInnerHTML={{ __html: props.text }} />
      <div className={expandedText('expand-button')}>↓</div>
    </section>
  )
}
