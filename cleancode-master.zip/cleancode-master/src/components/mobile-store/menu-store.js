import { action, computed, decorate, observable } from 'mobx'

class Menu {
    page = 1

    setPage (page) {
      this.page = page
    }

    get Page () {
      return this.page
    }
}

decorate(Menu, {
  page: observable,
  setPage: action,
  Page: computed
})

const menuStore = new Menu()

export default menuStore
